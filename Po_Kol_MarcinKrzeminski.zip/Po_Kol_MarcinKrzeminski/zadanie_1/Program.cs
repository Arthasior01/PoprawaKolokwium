﻿using System;

namespace zadanie_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Baza.Instance.SetDatabaseName("baza1");
            Osoba e1 = new Osoba();
            e1.GetById(1);
            e1.GetAll();
            Samochod s1 = new Samochod();
            s1.GetWhere("marka", "Ford");
            s1.GetById(7);


            
        }
    }
    public sealed class Baza
    {
        private static readonly Baza instance = new Baza();
        private string dbName;

        static Baza()
        {
        }

        private Baza()
        {
        }

        public static Baza Instance
        {
            get
            {
                return instance;
            }
        }
        public void SetDatabaseName(string _dbName)
        {
            dbName = _dbName;
        }
        private void Polacz()
        {
            Console.WriteLine("Polaczono z baza " + dbName);
        }
        private void Rozlacz()
        {
            Console.WriteLine("Rozlaczona z baza " + dbName);
        }
        public void UruchomZapytanie(Zapytanie z)
        {
            try
            {
                if (dbName != null)
                {
                    Polacz();
                    Console.WriteLine(z);
                    Rozlacz();
                }
                else
                {
                    throw new NiePolaczonyException("Nie polaczono bazy");
                }
            }
            catch(NiePolaczonyException e)
            {
                Console.WriteLine(e.Message);
            }
            
        }
    }
    public abstract class Encja
    {
        protected string tabela { get; }

        protected Encja()
        {
            this.tabela = this.GetType().Name.ToLower();
        }

        public void GetById(int id)
        {
             Baza.Instance.UruchomZapytanie(new Zapytanie($"SELECT * FROM {tabela} where id = {id};"));
        }

        public void GetAll()
        {
             Baza.Instance.UruchomZapytanie(new Zapytanie($"SELECT * FROM {tabela};"));
        }
        public void GetWhere(string kolumna, string wartosc)
        {
            Baza.Instance.UruchomZapytanie(new Zapytanie($"SELECT * FROM {tabela} where {kolumna} = {wartosc};"));
        }
    }
    public class Zapytanie
    {
        string _zapytanie;

        public Zapytanie(string zapytanie)
        {
            _zapytanie = zapytanie;
        }

        public override string ToString()
        {
            return _zapytanie;
        }
    }
    class NiePolaczonyException : Exception
    {
        public NiePolaczonyException(string message) : base (message)
        {

        }
    }
    public class Osoba : Encja
    {
       
    }
    public class Samochod : Encja
    {
        
    }



}
