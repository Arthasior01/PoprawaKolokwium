﻿using System;
using System.Collections.Generic;

namespace zadanie_2
{
    class Program
    {
        static void Main(string[] args)
        {
            OkretPodwodny o1 = new OkretPodwodny("Orka");
            //tu powinny zostac wywolane metody buildera zwracajace liste zbudowanych i zaladowanych czesci uzbrojenia ale cos nie dziala i nie mam pojecia co
            // :)
            
            
            
            





        }
    }

    public enum Typ { Dzialko_Plot_35mm, Dzialo_150mm, Dzialo_kinetyczne_250mm, WyrzutniaRakiet, BombaGlebinowa, WyrzutniaTorped };
    public class Uzbrojenie
    {
        private Typ _typ;
        string NumerSeryjny;

        public Uzbrojenie(Typ typ, string numerSeryjny)
        {
            _typ = typ;
            NumerSeryjny = numerSeryjny;
        }
    }
    public abstract class Okret
    {
        string nazwa;
        List<Uzbrojenie> uzbrojenie;

        protected Okret(string nazwa)
        {
            this.nazwa = nazwa;
        }

        public void MontujUzbrojenie(Uzbrojenie u)
        {
            uzbrojenie.Add(u);
        }
    }
    public class Pancernik : Okret
    {
        public Pancernik(string nazwa) : base(nazwa)
        {
        }
    }
    public class OkretPodwodny : Okret
    {
        public OkretPodwodny(string nazwa) : base(nazwa)
        {
        }
    }
    public class Niszczyciel : Okret
    {
        public Niszczyciel(string nazwa) : base(nazwa)
        {
        }
    }
    public class Korweta : Okret
    {
        public Korweta(string nazwa) : base(nazwa)
        {
        }
    }
    public class FabrykaUzbrojenia
    {
        public static int Id = 0000000;
        public static List<Uzbrojenie> BudujUzbrojenie (string typOkretu)
        {
            List<Uzbrojenie> u = new List<Uzbrojenie>();

            if(typOkretu=="Pancernik")
            {
                for(int i=0;i<2;i++)
                {
                    Id = Id + 1;
                    Uzbrojenie u1 = new Uzbrojenie(Typ.Dzialko_Plot_35mm, "SD" + Id );
                    u.Add(u1);
                }
                for (int i = 0; i < 8; i++)
                {
                    Id = Id + 1;
                    Uzbrojenie u1 = new Uzbrojenie(Typ.Dzialo_150mm, "SD" + Id );
                    u.Add(u1);
                }
                for (int i = 0; i < 2; i++)
                {
                    Id = Id + 1;
                    Uzbrojenie u1 = new Uzbrojenie(Typ.WyrzutniaRakiet, "SD" + Id );
                    u.Add(u1);
                }
                for (int i = 0; i < 2; i++)
                {
                    Id = Id + 1;
                    Uzbrojenie u1 = new Uzbrojenie(Typ.Dzialo_kinetyczne_250mm, "SD" + Id);
                    u.Add(u1);
                }
            }
            else if(typOkretu== "Niszczyciel")
            {
                for (int i = 0; i < 2; i++)
                {
                    Id = Id + 1;
                    Uzbrojenie u1 = new Uzbrojenie(Typ.Dzialko_Plot_35mm, "SD" + Id );
                    u.Add(u1);
                }
                for (int i = 0; i < 4; i++)
                {
                    Id = Id + 1;
                    Uzbrojenie u1 = new Uzbrojenie(Typ.Dzialo_150mm, "SD" + Id);
                    u.Add(u1);
                }
                for (int i = 0; i < 10; i++)
                {
                    Id = Id + 1;
                    Uzbrojenie u1 = new Uzbrojenie(Typ.BombaGlebinowa, "SD" + Id);
                    u.Add(u1);
                }
                for (int i = 0; i < 4; i++)
                {
                    Id = Id + 1;
                    Uzbrojenie u1 = new Uzbrojenie(Typ.WyrzutniaTorped, "SD" + Id);
                    u.Add(u1);
                }
            }
            else if(typOkretu=="OkretPodwodny")
            {
                for (int i = 0; i < 1; i++)
                {
                    Id = Id + 1;
                    Uzbrojenie u1 = new Uzbrojenie(Typ.Dzialko_Plot_35mm, "SD" + Id);
                    u.Add(u1);
                }
                for (int i = 0; i < 4; i++)
                {
                    Id = Id + 1;
                    Uzbrojenie u1 = new Uzbrojenie(Typ.WyrzutniaTorped, "SD" + Id);
                    u.Add(u1);
                }
            }
            else if(typOkretu=="Korweta")
            {
                for (int i = 0; i < 1; i++)
                {
                    Id = Id + 1;
                    Uzbrojenie u1 = new Uzbrojenie(Typ.Dzialko_Plot_35mm, "SD" + Id);
                    u.Add(u1);
                }
                for (int i = 0; i < 2; i++)
                {
                    Id = Id + 1;
                    Uzbrojenie u1 = new Uzbrojenie(Typ.WyrzutniaTorped, "SD" + Id);
                    u.Add(u1);
                }
                for (int i = 0; i < 2; i++)
                {
                    Id = Id + 1;
                    Uzbrojenie u1 = new Uzbrojenie(Typ.Dzialo_150mm, "SD" + Id);
                    u.Add(u1);
                }
            }
            return u;

            

        }
    }

}
